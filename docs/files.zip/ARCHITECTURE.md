# Loom: a Vim-native agent system

A design for coding with AI agents where the repository stays the only source of
truth, Vim stays a first-class client, and model choice is a config value rather
than a lock-in.

Built around four goals, in priority order:

1. **No usage lockout.** Structurally reduce how many tokens the expensive model
   sees, and keep a working fallback when any single provider is unavailable.
2. **Lower cost.** Route by difficulty, not by habit.
3. **Provider flexibility.** Swap Anthropic, Z.ai, Moonshot, DeepSeek without
   touching workflow.
4. **Keep hand-programming alive.** Some code is yours to write. The system
   enforces that rather than hoping you remember.

---

## 1. The core idea

Most agent tooling fails Vim users for one reason: the agent holds state the
editor cannot see. Conversation history, file context, pending edits, plan — all
of it lives inside a chat session. Vim becomes a spectator.

Invert it. **Every durable artifact is a file in the repo.** Plans, task specs,
architecture decisions, review notes, the agent's own instructions. If it only
exists in a session, it does not exist.

That single constraint gets you everything else:

- Vim can read and edit any of it, because it is all text on disk.
- Agents are interchangeable, because they read and write files rather than
  holding proprietary state.
- Cost drops, because a plan written once is re-read for a few hundred tokens
  instead of re-derived for fifty thousand.
- Lockout risk drops, because the expensive model rarely needs the whole codebase
  in context.

The second constraint follows from the first: **agents never write to your
working tree.** They get git worktrees. You review by diff. Your buffer is never
mutated underneath you.

---

## 2. Layers

```
┌──────────────────────────────────────────────────────┐
│  You + Vim/Neovim        edit, review, hand-write    │
├──────────────────────────────────────────────────────┤
│  Contract layer          .agents/{plans,tasks,...}   │  ← plain markdown
├──────────────────────────────────────────────────────┤
│  Execution layer         opencode agents, per-role   │  ← model routing
│                          model assignment            │
├──────────────────────────────────────────────────────┤
│  Isolation layer         git worktrees, one per task │
├──────────────────────────────────────────────────────┤
│  Gate                    fmt / clippy / test / check │  ← deterministic
└──────────────────────────────────────────────────────┘
```

Nothing crosses a layer except through files and git.

---

## 3. Roles and model assignment

Four roles. The point of the split is that intelligence and token volume are
inversely correlated in real coding work.

| Role | Model tier | Token share | Writes to |
|---|---|---|---|
| `architect` | Claude Fable / Opus | ~5% | `.agents/**` only |
| `scout` | cheap, read-only | ~50% | nothing |
| `implementer` | GLM / Kimi / DeepSeek | ~35% | one worktree, declared files |
| `reviewer` | mid-tier, *different provider* | ~10% | `.agents/reviews/**` |

### architect

Reads the plan request, consults `scout` for facts, writes a plan file and a set
of task files. Has `edit` permission scoped to `.agents/`. It cannot touch source.
This is not a safety measure so much as a cost measure: an architect that cannot
edit code will not be tempted to read all of it.

Its output is a durable artifact. That is the whole economic argument. You pay
premium rates once for a design, then re-read it for pennies on every subsequent
session.

### scout

Read-only exploration. "Where is the resampler called from, what does it assume
about sample rate, which tests cover it." Runs on a cheap model.

This is the single biggest cost lever in the system. Codebase exploration is the
majority of tokens in agentic coding and needs a fraction of the intelligence.
Sending `grep`-and-summarize work to a frontier model is where large-codebase
sessions burn quota.

### implementer

Gets exactly one task file and one worktree. Its instructions name the files it
may touch. It is not done until the gate passes.

### reviewer

Reads `git diff` against the task spec. Deliberately runs on a **different
provider than the implementer**, so failure modes are decorrelated. A GLM
implementation reviewed by GLM will share blind spots. Reviewed by DeepSeek or
Kimi, it will not.

---

## 4. Why this works especially well for Rust

Cheap models make more mistakes. The question is whether the mistakes are caught
for free.

In Rust they largely are. `rustc` plus `clippy -D warnings` is a deterministic,
zero-cost reviewer that rejects most of what a weaker model gets wrong: lifetime
errors, ownership confusion, unhandled `Result`, missing match arms, type
mismatches at boundaries. The gate turns model weakness into a compile loop
rather than a bug you find in three weeks.

The practical consequence: **you can push the implementer tier lower in Rust than
you could in Python.** Budget accordingly.

For `audat` specifically, the useful boundary is roughly:

- Numeric correctness of DSP is *not* well covered by the type system. Keep that
  in the hand zone, and back it with property tests and known-signal fixtures.
- Everything structural — trait plumbing, CLI parsing, file format decoding,
  error types, test scaffolding, benchmark harnesses — is well covered. Delegate it.

---

## 5. Hand zones

The skill-maintenance goal needs enforcement, not intention. `.agents/zones.toml`
declares three zones:

- **`hand`** — agents may read and may propose, never edit. Your learning surface.
- **`assist`** — agents edit, you review every diff.
- **`auto`** — agents edit, you review the summary.

A pre-commit hook rejects any commit on an `agent/*` branch that touches a `hand`
path. Convention alone drifts within a month; the hook does not.

### Tutor mode

Hand zones still get leverage, just inverted. Ask the architect to write:

- the failing test,
- the doc comment stating the contract and invariants,
- the type signatures,

and leave the body as `todo!()`. You fill it in. You get the design conversation
and the specification for free, and you still write the code. For learning Rust
this is better than either extreme, because the hard part of Rust is not
syntax — it is knowing what shape the solution should take.

---

## 6. Lockout avoidance, concretely

Two lockouts on large codebases is a symptom with a specific cause: a single
agent repeatedly pulling large amounts of the codebase into a frontier model's
context. Four mitigations, in order of effectiveness.

**1. Structural — the architect rarely sees code.** It sees plan files, a repo
map, and scout summaries. This is worth an order of magnitude more than the
other three combined.

**2. Billing — separate the quota you can exhaust from the one you cannot.**
Put the architect on API-key billing rather than a subscription seat, or keep the
subscription as the *fallback* rather than the primary. A subscription rate limit
stops your day; an API bill does not.

**3. Tiering — one env var drops the whole system a level.**

```sh
export LOOM_TIER=lean      # everything cheap, architect on GLM/Kimi
export LOOM_TIER=standard  # default
export LOOM_TIER=deep      # architect on Fable, reviewer mid-tier
```

When you hit a wall, `LOOM_TIER=lean` and keep working, degraded.

**4. Fallback chain.** Each role names an ordered list. If Anthropic returns 429
or is unavailable, the architect runs on GLM. The plan will be worse. You will
not be stopped.

---

## 7. The contract format

A plan is a markdown file with a fixed shape. Fixed shape matters because it is
what lets a cheap model act on it reliably.

```markdown
# Plan 0007 — Streaming resampler

## Goal
One paragraph. What is true after this is done.

## Constraints
- No allocation in the hot path
- Must handle 44.1k ↔ 48k exactly
- Public API stays additive

## Design
The reasoning. This is the expensive part and the part worth keeping.

## Interfaces
```rust
pub trait Resampler { ... }
```

## Tasks
- [ ] 0007-a  Trait + error types        assist  crates/audat-dsp/src/resample/mod.rs
- [ ] 0007-b  Sinc kernel                HAND    crates/audat-dsp/src/resample/sinc.rs
- [ ] 0007-c  CLI wiring                 auto    crates/audat-cli/src/cmd/resample.rs
- [ ] 0007-d  Property tests             assist  crates/audat-dsp/tests/resample.rs

## Acceptance
`./.agents/gate.sh` green, plus `cargo test -p audat-dsp resample::` covers
round-trip error < -96 dBFS.
```

Each unchecked task becomes a task file. Each task file is one worktree, one
implementer run, one diff to review.

Note task `0007-b` is marked `HAND`. The sinc kernel is the interesting part.
You write that one.

---

## 8. Vim integration, three tiers

**Tier 0 works in plain Vim, no plugins.** This is the baseline and it is
genuinely sufficient.

```
tmux window
┌────────────────────┬──────────────────┐
│                    │  opencode TUI    │
│   vim              ├──────────────────┤
│                    │  cargo watch     │
└────────────────────┴──────────────────┘
```

- `:cfile` the gate output into quickfix, `]q` / `[q` to walk errors.
- `:!git diff agent/0007-c` to review, or `:Gdiffsplit` with fugitive.
- `:e .agents/plans/0007-*.md`, then `gf` on a path to jump to the source.
- `:r !aw scout "where is decode_flac called"` to drop an answer into a buffer.

**Tier 1 adds Neovim terminal management.** `agents.nvim` gives each CLI agent a
persistent terminal buffer you can hide, cycle, and send prompts to without
losing the running job. It does not invent a chat UI or own your layout, which is
what you want.

**Tier 2 adds `opencode.nvim`** for a chat panel that captures buffer and
selection context automatically. Useful, optional, and the thing most likely to
break on upgrade. Do not build the workflow on it.

Included keymaps in `nvim/loom.lua`:

| Key | Action |
|---|---|
| `<leader>ag` | run gate, results into quickfix |
| `<leader>ap` | open current plan |
| `<leader>ar` | review current task diff in a vertical split |
| `<leader>as` | ask scout about the word under cursor |
| `<leader>az` | show which zone the current file is in |

---

## 9. Session loop

```
  you ──▶ architect ──▶ .agents/plans/0007.md      [premium, ~5% of tokens]
                    └─▶ .agents/tasks/0007-*.md
                             │
                    ┌────────┴────────┐
              HAND tasks         assist/auto tasks
                    │                 │
                  you              aw run 0007-c    [cheap]
                  in vim               │
                    │            worktree + gate
                    │                 │
                    │              reviewer         [mid, other provider]
                    │                 │
                    └───────▶  aw review / aw land
```

The architect is invoked at the start of a feature and when a plan turns out to
be wrong. Not otherwise. If you find yourself in a long conversation with the
expensive model, that is the signal to stop and write a plan file instead.

---

## 10. What this costs

Rough shape, not a quote. Assume a feature that would be 200k tokens of
single-agent frontier work:

| Approach | Frontier tokens | Cheap tokens |
|---|---|---|
| One frontier agent | 200k | 0 |
| This system | ~12k (plan + review of plan) | ~190k |

The frontier share drops by more than an order of magnitude, which is the
lockout fix. Absolute cost drops by roughly the ratio of the price difference on
the 95% you moved.

The second-order saving is larger and harder to quantify: plan files mean the
next session starts from a written design rather than re-deriving it.

---

## 11. Failure modes to watch

**Plan rot.** A plan file that no longer matches the code is worse than none.
Land plan updates in the same commit as the code, and treat a stale plan as a bug.

**Cheap model thrash.** If an implementer fails the gate three times, stop. Do
not let it loop. The task spec is probably wrong, which is an architect problem.
`aw run` enforces a retry cap for this reason.

**Zone creep.** Watch for `hand` paths quietly getting reclassified because a task
was inconvenient. Review `zones.toml` diffs like you would review a security
policy.

**Scout hallucination.** A cheap model summarizing a codebase will occasionally
invent a function. Require scout to return file:line citations and have the
architect treat uncited claims as unknown.

---

## 12. Setup order

1. `bin/aw` on your `PATH`, `.agents/gate.sh` executable.
2. `.agents/zones.toml` — five minutes, do it honestly.
3. `AGENTS.md` at repo root. Keep it under 100 lines. It is read on every call.
4. `.opencode/opencode.json` — set your API keys as env vars, run
   `opencode models` to confirm current model IDs before trusting the ones in the
   config.
5. Install the pre-commit hook: `bin/aw install-hooks`.
6. Run one small feature end to end before trusting it with anything real.

Model IDs move quickly. The config ships with plausible IDs and a comment; verify
them against `opencode models` rather than assuming.
